# basic vars and imports maybe needed, maybe not
#

import pygame
from pygame.locals import *

pygame.font.init()
from pygame.constants import *

from pygame.constants import MOUSEMOTION, MOUSEBUTTONUP
# from pytmx import load_pygame
import random

# import pytmx


clock = pygame.time.Clock()

screen = pygame.display.set_mode((1010, 700), pygame.FULLSCREEN)
SCREENWIDTH = screen.get_width()
SCREENHEIGHT = screen.get_height()
start = True
font = pygame.font.Font(None, 30)

startScreenSprites = pygame.sprite.Group()

pickCharScreenSprites = pygame.sprite.Group()
charScreenSprites = pygame.sprite.Group()

infoSprites = pygame.sprite.Group()


curLevelSprites = pygame.sprite.Group()
curLevelEnemies = pygame.sprite.Group()
curLevelplayers = pygame.sprite.Group()

allSprites = pygame.sprite.Group()

################################################################
# startButton = pygame.transform.scale(startButton.image, (startButton.rect.width*2, startButton.rect.height*2))
