# the characters and enemies

from base import *


class Dog(pygame.sprite.Sprite):
    def __init__(self, location, ):
        super(Dog, self).__init__()
        pygame.sprite.Sprite.__init__(self)
        self.surf = pygame.image.load("sprites/dog/dog1.png")
        self.rect = self.surf.get_rect()
        self.rect.left, self.rect.top = location
        self.startPos = location

    def update(self):
        pass
class Kid(pygame.sprite.Sprite):
    def __init__(self, location, ):
        super(Kid, self).__init__()
        pygame.sprite.Sprite.__init__(self)
        self.surf = pygame.image.load("sprites/kid/kid1.png")
        self.rect = self.surf.get_rect()
        self.rect.left, self.rect.top = location
        self.startPos = location

    def update(self):
        pass
class Hiker(pygame.sprite.Sprite):
    def __init__(self, location, ):
        super(Hiker, self).__init__()
        pygame.sprite.Sprite.__init__(self)
        self.surf = pygame.image.load("sprites/otherChars/hiker.png")
        self.rect = self.surf.get_rect()
        self.rect.left, self.rect.top = location
        self.startPos = location

    def update(self):
        pass
class ScreenGirl(pygame.sprite.Sprite):
    def __init__(self, location, ):
        super(ScreenGirl, self).__init__()
        pygame.sprite.Sprite.__init__(self)
        self.surf = pygame.image.load("sprites/otherChars/ScreenGirl.png")
        self.rect = self.surf.get_rect()
        self.rect.left, self.rect.top = location
        self.startPos = location

    def update(self):
        pass
class AnxiousPerson(pygame.sprite.Sprite):
    def __init__(self, location, ):
        super(AnxiousPerson, self).__init__()
        pygame.sprite.Sprite.__init__(self)
        self.surf = pygame.image.load("sprites/redGuy1.png")
        self.rect = self.surf.get_rect()
        self.rect.left, self.rect.top = location
        self.startPos = location

    def update(self):
        pass
class Jock(pygame.sprite.Sprite):
    def __init__(self, location, ):
        super(Jock, self).__init__()
        pygame.sprite.Sprite.__init__(self)
        self.surf = pygame.image.load("sprites/otherChars/jock.png")
        self.rect = self.surf.get_rect()
        self.rect.left, self.rect.top = location
        self.startPos = location

    def update(self):
        pass
class AnimalHippie(pygame.sprite.Sprite):
    def __init__(self, location, ):
        super(AnimalHippie, self).__init__()
        pygame.sprite.Sprite.__init__(self)
        self.surf = pygame.image.load("sprites/otherChars/Nature Person.png")
        self.rect = self.surf.get_rect()
        self.rect.left, self.rect.top = location
        self.startPos = location

    def update(self):
        pass
class Nerd(pygame.sprite.Sprite):
    def __init__(self, location, ):
        super(Nerd, self).__init__()
        pygame.sprite.Sprite.__init__(self)
        self.surf = pygame.image.load("sprites/otherChars/Nerd.png")
        self.rect = self.surf.get_rect()
        self.rect.left, self.rect.top = location
        self.startPos = location

    def update(self):
        pass
