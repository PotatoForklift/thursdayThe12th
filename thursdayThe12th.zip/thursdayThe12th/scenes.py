from chars import *

floor1 = ['empty', 'event', 'empty', 'empty', 'fight', 'healing']
floor2 = ['empty', 'random', 'random', 'random', 'random', 'random', 'empty', 'fight', 'healing']
floor3 = ['empty', 'random', 'random', 'random', 'random', 'random', 'empty', 'fight', 'healing']
floor4 = ['empty', 'random', 'random', 'random', 'random', 'random', 'random', 'empty', 'fight', 'healing']
floor5 = ['healing', 'fight', 'fight', 'fight', 'THE END']

def scene1emp():
    pass
